#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x8 - 0x0)
// Function BI_PalInteractHUDInterface.BI_PalInteractHUDInterface_C.GetInteractWidget
struct IBI_PalInteractHUDInterface_C_GetInteractWidget_Params
{
public:
	class UPalUserWidget*                        CreatedWidget;                                     // 0x0(0x8)(Parm, OutParm, ZeroConstructor, InstancedReference, NoDestructor, HasGetValueTypeHash)
};

}
}


