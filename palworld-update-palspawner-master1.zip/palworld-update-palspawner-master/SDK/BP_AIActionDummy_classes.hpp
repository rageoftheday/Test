#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x130 - 0x130)
// BlueprintGeneratedClass BP_AIActionDummy.BP_AIActionDummy_C
class UBP_AIActionDummy_C : public UPalAIActionBase
{
public:

	static class UClass* StaticClass();
	static class UBP_AIActionDummy_C* GetDefaultObj();

};

}


