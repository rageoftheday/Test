#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BP_AIAction_BaseCamp_DodgeWork.BP_AIAction_BaseCamp_DodgeWork_C
class UBP_AIAction_BaseCamp_DodgeWork_C : public UPalAIActionBaseCampDodgeWork
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCamp_DodgeWork_C* GetDefaultObj();

};

}


