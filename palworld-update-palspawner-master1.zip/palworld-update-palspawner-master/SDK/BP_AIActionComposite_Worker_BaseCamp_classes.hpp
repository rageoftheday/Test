#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA0 - 0xA0)
// BlueprintGeneratedClass BP_AIActionComposite_Worker_BaseCamp.BP_AIActionComposite_Worker_BaseCamp_C
class UBP_AIActionComposite_Worker_BaseCamp_C : public UPalAIActionCompositeWorkerBaseCamp
{
public:

	static class UClass* StaticClass();
	static class UBP_AIActionComposite_Worker_BaseCamp_C* GetDefaultObj();

};

}


