#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x98 - 0x98)
// BlueprintGeneratedClass BP_AIActionComposite_BaseCamp.BP_AIActionComposite_BaseCamp_C
class UBP_AIActionComposite_BaseCamp_C : public UPalAIActionCompositeBaseCamp
{
public:

	static class UClass* StaticClass();
	static class UBP_AIActionComposite_BaseCamp_C* GetDefaultObj();

};

}


