#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x170 - 0x170)
// BlueprintGeneratedClass BP_AIAction_BaseCampRecoverHungry_Eat.BP_AIAction_BaseCampRecoverHungry_Eat_C
class UBP_AIAction_BaseCampRecoverHungry_Eat_C : public UPalAIActionBaseCampRecoverHungryEat
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampRecoverHungry_Eat_C* GetDefaultObj();

};

}


