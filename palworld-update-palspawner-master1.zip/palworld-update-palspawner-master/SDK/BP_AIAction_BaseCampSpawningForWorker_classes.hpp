#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x140 - 0x140)
// BlueprintGeneratedClass BP_AIAction_BaseCampSpawningForWorker.BP_AIAction_BaseCampSpawningForWorker_C
class UBP_AIAction_BaseCampSpawningForWorker_C : public UPalAIActionBaseCampSpawningForWorker
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampSpawningForWorker_C* GetDefaultObj();

};

}


