#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x2C0 (0x2C0 - 0x0)
// Function BP_AIActionPairCall_FeedItem.BP_AIActionPairCall_FeedItem_C.CreatePairBehaviorActionDynamicParameter
struct UBP_AIActionPairCall_FeedItem_C_CreatePairBehaviorActionDynamicParameter_Params
{
public:
	struct FActionDynamicParameter               DynamicParameter;                                  // 0x0(0xE0)(Parm, OutParm)
	struct FPalNetArchive                        Blackboard;                                        // 0xE0(0x10)(Edit, BlueprintVisible)
	struct FActionDynamicParameter               Parameter;                                         // 0xF0(0xE0)(Edit, BlueprintVisible)
	struct FPalNetArchive                        K2Node_MakeStruct_PalNetArchive;                   // 0x1D0(0x10)(None)
	struct FActionDynamicParameter               CallFunc_CreatePairBehaviorActionDynamicParameter_DynamicParameter; // 0x1E0(0xE0)(None)
};

}
}


