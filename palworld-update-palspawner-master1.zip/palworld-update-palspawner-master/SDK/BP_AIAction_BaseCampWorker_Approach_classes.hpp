#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BP_AIAction_BaseCampWorker_Approach.BP_AIAction_BaseCampWorker_Approach_C
class UBP_AIAction_BaseCampWorker_Approach_C : public UBP_AIAction_Worker_Approach_C
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampWorker_Approach_C* GetDefaultObj();

};

}


