#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x138 - 0x130)
// BlueprintGeneratedClass BP_AIAction_Invader_Idle.BP_AIAction_Invader_Idle_C
class UBP_AIAction_Invader_Idle_C : public UPalAIActionBase
{
public:
	struct FPointerToUberGraphFrame              UberGraphFrame;                                    // 0x130(0x8)(ZeroConstructor, Transient, DuplicateTransient)

	static class UClass* StaticClass();
	static class UBP_AIAction_Invader_Idle_C* GetDefaultObj();

	void ExecuteUbergraph_BP_AIAction_Invader_Idle(int32 EntryPoint);
};

}


