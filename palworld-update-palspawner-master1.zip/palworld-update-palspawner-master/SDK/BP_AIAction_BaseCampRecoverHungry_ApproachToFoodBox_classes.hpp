#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x148 - 0x148)
// BlueprintGeneratedClass BP_AIAction_BaseCampRecoverHungry_ApproachToFoodBox.BP_AIAction_BaseCampRecoverHungry_ApproachToFoodBox_C
class UBP_AIAction_BaseCampRecoverHungry_ApproachToFoodBox_C : public UPalAIActionBaseCampRecoverHungryApproachToFoodBox
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampRecoverHungry_ApproachToFoodBox_C* GetDefaultObj();

};

}


