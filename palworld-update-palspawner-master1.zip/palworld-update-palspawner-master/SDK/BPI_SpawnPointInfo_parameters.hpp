#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0xA0 (0xA0 - 0x0)
// Function BPI_SpawnPointInfo.BPI_SpawnPointInfo_C.GetOneSpawnInfo
struct IBPI_SpawnPointInfo_C_GetOneSpawnInfo_Params
{
public:
	struct FF_NPCOnePointSpawnInfo               Info;                                              // 0x0(0x98)(Parm, OutParm, HasGetValueTypeHash)
	uint8                                        Pad_4965[0x8];                                     // Fixing Size Of Struct [ Dumper-7 ]
};

}
}


