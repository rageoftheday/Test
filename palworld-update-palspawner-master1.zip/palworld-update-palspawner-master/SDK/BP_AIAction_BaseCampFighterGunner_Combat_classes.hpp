#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x188 - 0x188)
// BlueprintGeneratedClass BP_AIAction_BaseCampFighterGunner_Combat.BP_AIAction_BaseCampFighterGunner_Combat_C
class UBP_AIAction_BaseCampFighterGunner_Combat_C : public UPalAIActionBaseCampFighterCombatGunner
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampFighterGunner_Combat_C* GetDefaultObj();

};

}


