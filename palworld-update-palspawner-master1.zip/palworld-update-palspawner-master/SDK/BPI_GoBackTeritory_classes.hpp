#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass BPI_GoBackTeritory.BPI_GoBackTeritory_C
class IBPI_GoBackTeritory_C : public IInterface
{
public:

	static class UClass* StaticClass();
	static class IBPI_GoBackTeritory_C* GetDefaultObj();

	void GoBack_Teritory();
};

}


