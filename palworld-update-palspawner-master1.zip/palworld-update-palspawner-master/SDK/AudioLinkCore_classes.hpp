#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x38 - 0x28)
// Class AudioLinkCore.AudioLinkSettingsAbstract
class UAudioLinkSettingsAbstract : public UObject
{
public:
	uint8                                        Pad_295D[0x10];                                    // Fixing Size Of Struct [ Dumper-7 ]

	static class UClass* StaticClass();
	static class UAudioLinkSettingsAbstract* GetDefaultObj();

};

}


