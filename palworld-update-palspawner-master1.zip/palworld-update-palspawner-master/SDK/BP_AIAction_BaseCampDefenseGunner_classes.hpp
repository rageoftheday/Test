#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x190 - 0x190)
// BlueprintGeneratedClass BP_AIAction_BaseCampDefenseGunner.BP_AIAction_BaseCampDefenseGunner_C
class UBP_AIAction_BaseCampDefenseGunner_C : public UPalAIActionBaseCampDefenseGunner
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampDefenseGunner_C* GetDefaultObj();

};

}


