#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x188 - 0x188)
// BlueprintGeneratedClass BP_AIAction_BaseCampDefenseWait.BP_AIAction_BaseCampDefenseWait_C
class UBP_AIAction_BaseCampDefenseWait_C : public UPalAIActionBaseCampDefenseWait
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampDefenseWait_C* GetDefaultObj();

};

}


