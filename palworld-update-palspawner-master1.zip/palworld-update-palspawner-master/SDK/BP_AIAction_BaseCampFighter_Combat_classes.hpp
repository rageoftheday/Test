#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x178 - 0x178)
// BlueprintGeneratedClass BP_AIAction_BaseCampFighter_Combat.BP_AIAction_BaseCampFighter_Combat_C
class UBP_AIAction_BaseCampFighter_Combat_C : public UPalAIActionBaseCampFighterCombat
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_BaseCampFighter_Combat_C* GetDefaultObj();

};

}


