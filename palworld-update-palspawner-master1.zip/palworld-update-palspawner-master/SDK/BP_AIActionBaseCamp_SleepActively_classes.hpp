#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1A0 - 0x1A0)
// BlueprintGeneratedClass BP_AIActionBaseCamp_SleepActively.BP_AIActionBaseCamp_SleepActively_C
class UBP_AIActionBaseCamp_SleepActively_C : public UPalAIActionBaseCampSleepActively
{
public:

	static class UClass* StaticClass();
	static class UBP_AIActionBaseCamp_SleepActively_C* GetDefaultObj();

};

}


