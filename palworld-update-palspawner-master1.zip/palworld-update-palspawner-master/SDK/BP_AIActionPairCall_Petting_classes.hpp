#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x150 - 0x150)
// BlueprintGeneratedClass BP_AIActionPairCall_Petting.BP_AIActionPairCall_Petting_C
class UBP_AIActionPairCall_Petting_C : public UBP_AIActionPairCallBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_AIActionPairCall_Petting_C* GetDefaultObj();

};

}


