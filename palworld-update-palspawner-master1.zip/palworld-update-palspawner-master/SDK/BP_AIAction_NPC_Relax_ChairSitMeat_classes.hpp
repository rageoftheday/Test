#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1F1 - 0x1F1)
// BlueprintGeneratedClass BP_AIAction_NPC_Relax_ChairSitMeat.BP_AIAction_NPC_Relax_ChairSitMeat_C
class UBP_AIAction_NPC_Relax_ChairSitMeat_C : public UBP_AIAction_NPC_Relax_ChairSit_Base_C
{
public:

	static class UClass* StaticClass();
	static class UBP_AIAction_NPC_Relax_ChairSitMeat_C* GetDefaultObj();

};

}


